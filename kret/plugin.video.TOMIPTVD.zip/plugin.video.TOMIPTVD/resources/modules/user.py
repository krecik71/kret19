import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLlRPTUlQVFZE')

name = b.b64decode('VE9NSVBUVkQ=')

#host = b.b64decode('aHR0cDovLzE0NC4yMTcuNzguNzg=')
host = b.b64decode('aHR0cDovL3R2bGF0aW5hLmhvbWVpcC5uZXQ=')
port = b.b64decode('MjU0NjE=')
