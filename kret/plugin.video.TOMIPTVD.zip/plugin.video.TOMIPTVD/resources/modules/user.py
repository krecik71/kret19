import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLlRPTUlQVFZE')

name = b.b64decode('VE9NSVBUVkQ=')

#host = b.b64decode('aHR0cDovLzE0NC4yMTcuNzguNzg=')
host = b.b64decode('aHR0cDovL3BvcnRhbC5nZW5pcHR2LmNvbQ==')
port = b.b64decode('ODA4MA==')